# dumpwow

Tool to dump unpacked and deobfuscated World of Warcraft binaries.

Depends on the [hadesmem](https://bitbucket.org/raptorfactor/hadesmem/) library.